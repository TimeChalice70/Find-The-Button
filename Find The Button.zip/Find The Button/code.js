onEvent("lvlslctor", "click", function( ) {
  setScreen("levels");
});
onEvent("lvl2", "click", function( ) {
  setScreen("screen2");
});
onEvent("lvl3", "click", function( ) {
  setScreen("screen3");
});
onEvent("lvl4", "click", function( ) {
  setScreen("screen4");
});
onEvent("lvl5", "click", function( ) {
  setScreen("screen5");
});
onEvent("lvl6", "click", function( ) {
  setScreen("screen6");
});
onEvent("lvl7", "click", function( ) {
  setScreen("screen7");
});
onEvent("lvl8", "click", function( ) {
  setScreen("screen8");
});
onEvent("15", "click", function( ) {
  setScreen("screen15");
});
onEvent("lvl9", "click", function( ) {
  setScreen("screen9");
});
onEvent("button1", "click", function( ) {
  setScreen("screen2");
});
//first level,prestige 1 
onEvent("button2", "click", function( ) {
  setScreen("screen3");
});
//2nd level pst1
onEvent("button3", "click", function( ) {
  setScreen("screen4");
});
//4th level pst1
onEvent("button4", "click", function( ) {
  setScreen("screen5");
});
//5th level pst1
onEvent("button5", "click", function( ) {
  setScreen("screen6");
});
onEvent("button7", "click", function( ) {
  setScreen("screen7");
});
onEvent("button13", "click", function( ) {
  setScreen("screen8");
});
onEvent("button8", "click", function( ) {
  setScreen("screen9");
});
onEvent("button9", "click", function( ) {
  setScreen("screen10");
});
onEvent("button14", "click", function( ) {
  setScreen("screen11");
});
onEvent("button15", "click", function( ) {
  setScreen("screen12");
});
onEvent("button16", "click", function( ) {
  setScreen("screen13");
});
onEvent("button28", "click", function( ) {
  setScreen("screen14");
});
onEvent("button18", "click", function( ) {
  setScreen("screen15");
});
onEvent("button30", "click", function( ) {
  setScreen("screen16");
});
onEvent("button31", "click", function( ) {
  setScreen("screen17");
});
onEvent("button40", "click", function( ) {
  setScreen("screen18");
});
onEvent("button38", "click", function( ) {
  setScreen("screen20");
});
onEvent("button41", "click", function( ) {
  setScreen("screen21");
});
onEvent("button42", "click", function( ) {
  setScreen("screen1");
});
onEvent("button54", "click", function( ) {
  setScreen("screen19");
});
